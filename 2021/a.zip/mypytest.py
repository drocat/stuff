import  pytest
import sys
import slipper.slipper as ss
import slipper.logger as sl
from models.api.transcript import *


class Cfg:
    url = 'https://cos-1303988041.cos.ap-beijing.myqcloud.com/audio_half_minite.wav'
    aliyun_handler = AliyunASRHandler(ASRSourceEnum.aliyun.name, 1,
                                      ali_put_audio, ali_get_res, parse_aliyun)
    tencent_handler = TencentASRHandler(ASRSourceEnum.tencent.name, 2,
                                        tencent_put_audio, tencent_get_res,
                                        parse_tencent)
    asr_input = ASRInput(url, ASRClientEnum.default.name, hot_words=['Gong'])


def new_asr_input():
    return ASRInput(Cfg.url, ASRClientEnum.default.name, hot_words=['Gong'])


# @pytest.mark.skip(reason="Test passed already")
@pytest.mark.aliyun
def test_aliyun_asr():
    """阿里云转录程序可正常完成转录任务"""
    ai = new_asr_input()
    Cfg.aliyun_handler.handler(ai)
    assert ai.task_id is not None  # Create task success
    assert type(ai.task_id) is str  # TaskId is string
    assert type(ai.asr_res) is dict  # Result query returns dict
    res = ai.asr_res
    assert 'Sentences' in res  # Result has sentences
    assert len(res['Sentences']) >= 1


# @pytest.mark.skip(reason="Test passed already")
@pytest.mark.tencent
def test_tencent_asr():
    """腾讯云转录程序可正常完成转录任务"""
    ai = new_asr_input()
    Cfg.tencent_handler.handler(ai)

    assert ai.task_id is not None  # Create task success
    assert type(ai.task_id) is int  # TaskId is string
    assert type(ai.asr_res) is dict  # Result query returns dict
    res = ai.asr_res
    assert 'Sentences' in res  # Result has sentences
    assert len(res['Sentences']) >= 1


# @pytest.mark.skip(reason="Test passed already")
@pytest.mark.both
def test_run_in_order():
    """ 阿里云转录优先进行，阿里云转录成功，则腾讯云转录跳过。
    """
    handlers = [Cfg.aliyun_handler, Cfg.tencent_handler]
    ai = new_asr_input()
    for i, h in enumerate(handlers):
        if i == 0:
            assert ai.asr_res is None  # ars_res is none before aliyun run
            assert h.get_name == 'aliyun'
        else:
            assert type(ai.asr_res) is dict
            assert h.get_name == 'tencent'
            assert h.match(ai) == False  # 阿里云转录成功，则腾讯云转录跳过
        h.handler_(ai)
        sl.Logger().info(f"ASR {h.get_name}")


# @pytest.mark.skip(reason="Test passed already")
@pytest.mark.onlytencent
def test_when_aliyun_fails():
    """ 阿里云转录失败，则执行腾讯云转录
    """
    handlers = [Cfg.aliyun_handler, Cfg.tencent_handler]
    ai = new_asr_input()
    for i, h in enumerate(handlers):
        if i == 0:
            ai.audio_file_url = "suffix#" + ai.audio_file_url  # Fake audio file url to crash Aliyun ASR.
            assert ai.asr_res is None  # ars_res is none before aliyun run
            assert h.get_name == 'aliyun'
        else:
            ai.audio_file_url = ai.audio_file_url.split("#")[
                1]  # Restore audio file url
            assert ai.asr_res is None
            assert h.get_name == 'tencent'
            assert h.match(ai) == True  # 阿里云转录失败，则腾讯云转录进行
        h.handler_(ai)


# @pytest.mark.skip(reason="Test passed already")
@pytest.mark.onlytencent
def test_when_both_fail():
    """ 阿里云、腾讯云转录任务都失败，转录错误信息是否存储到日志中
    """
    handlers = [Cfg.aliyun_handler, Cfg.tencent_handler]
    ai = new_asr_input()
    ai.audio_file_url = "suffix#" + ai.audio_file_url  # Fake audio file url to crash ASR.
    for i, h in enumerate(handlers):
        if i == 0:
            assert ai.asr_res is None  # ars_res is none before aliyun run
            assert h.get_name == 'aliyun'
        else:
            assert ai.asr_res is None
            assert h.get_name == 'tencent'
            assert h.match(ai) == True  # 阿里云转录失败，则腾讯云转录进行
        h.handler_(ai)
