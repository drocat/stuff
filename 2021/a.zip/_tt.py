
from _ss import shared
import time

time.sleep(5)

import sys
shared = sys.argv[1]
print(shared)
