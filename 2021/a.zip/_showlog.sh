tail -f log/serving/serving.log 
