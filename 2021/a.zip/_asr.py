import requests
import sys
from models.api.transcript import *
import dofast as df
from pkgs.ali.asr import AliASR
import threading

class Cfg:
    url = 'https://cos-1303988041.cos.ap-beijing.myqcloud.com/audio_1_minute.wav'
    url = 'http://mgvai.free.idcfengye.com/audio_5_minutes.wav'
    # url = 'https://cos-1303988041.cos.ap-beijing.myqcloud.com/huihua.wav'
    aliyun_handler = AliyunASRHandler(ASRSourceEnum.aliyun.name, 1,
                                      ali_put_audio, ali_get_res, parse_aliyun)
    tencent_handler = TencentASRHandler(ASRSourceEnum.tencent.name, 2,
                                        tencent_put_audio, tencent_get_res,
                                        parse_tencent)
    asr_input = ASRInput(url, ASRClientEnum.default.name, hot_words=['Gong'])


def new_asr_input(url=None):
    if url is None:
        return ASRInput(Cfg.url, ASRClientEnum.default.name, hot_words=['Gong'])
    else:
        return ASRInput(url, ASRClientEnum.default.name)




# @pytest.mark.skip(reason="Test passed already")
def test_aliyun_asr():
    """阿里云转录程序可正常完成转录任务"""
    ai = new_asr_input()
    Cfg.aliyun_handler.handler(ai)
    
def test_tencent_asr():
    """腾讯云转录程序可正常完成转录任务"""
    ai = new_asr_input()
    Cfg.tencent_handler.handler(ai)


def cur():
    url10 = 'http://mgvai.free.idcfengye.com/audio_10_minutes.wav'
    url5 = 'http://mgvai.free.idcfengye.com/audio_5_minutes.wav'
    url_half = 'http://mgvai.free.idcfengye.com/audio_half_minute.wav'
    fake1 = 'http://mgvai.free.idcfengye.com/1second.wav'
    fake6 = 'http://mgvai.free.idcfengye.com/16seconds.wav'
    # audios = [url5] * 10
    audios = [url_half, url5, url10, fake1, fake6]
    audios = [url_half, url5, fake1, fake6]
    tasks = [new_asr_input(url) for url in audios]
    asr = ASR([Cfg.aliyun_handler])
    # , Cfg.tencent_handler])

    def doit(asr_input):
        asr.handler(asr_input)

    for i in range(len(tasks)):
        t = threading.Thread(target=doit, args=(tasks[i], ))
        # t = threading.Thread(target=sleepit, args=(audios[i],))
        t.start()
        # df.info("Hllll")

cur()

# def download_file(url):
#     local_filename = url.split('/')[-1]
#     # NOTE the stream=True parameter below
#     with requests.get(url, stream=True) as r:
#         r.raise_for_status()
#         with open(local_filename, 'wb') as f:
#             for chunk in r.iter_content(chunk_size=8192): 
#                 f.write(chunk)
#     return local_filename

# # test_aliyun_asr()
# # test_tencent_asr()

# # download_file('http://mgvai.free.idcfengye.com/6seconds.m4a')

