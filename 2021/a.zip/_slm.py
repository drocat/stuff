from pkgs.ali.alislm import AliSLM
from pkgs.ali.asr import AliASR
from configs.serving import TENCENT_SECRET_KEY, TENCENT_SECRTE_ID, ALIYUN_ASR_ACCESSKEYID, ALIYUN_ASR_ACCESSKEYSECRET, ALIYUN_ASR_APPKEY
from utils.core import clog

import dirtyfast as df 
import pdb

client=AliSLM(ALIYUN_ASR_ACCESSKEYID, ALIYUN_ASR_ACCESSKEYSECRET, ALIYUN_ASR_APPKEY)
asr=AliASR(ALIYUN_ASR_ACCESSKEYID, ALIYUN_ASR_ACCESSKEYSECRET, ALIYUN_ASR_APPKEY)


def pprint_models()->[str]:
    """
    Args:
    Returns:
    """
    models = client.get_model_list()
    pdb.set_trace()
    for m in models["Page"]["Content"]:
        name, status, description = m.get('Name', None), m.get('Status', None), m.get('Description', None)
        print("{:<10} {:<10} {:<30}".format(name, status, description))


def pprint_data()->[str]:
    """
    Args:
    Returns:
    """
    models = client.get_model_list()
    for m in models["Page"]["Content"]:
        name, status, description = m.get('Name', None), m.get('Status', None), m.get('Description', None)
        print("{:<10} {:<10} {:<30}".format(name, status, description))


def _audio_duration():
    url='https://cos-1303988041.cos.ap-beijing.myqcloud.com/audio_half_minite.wav'
    resp=asr._ffprobe_audio_duration(url)
    df.p(resp)

_audio_duration()


