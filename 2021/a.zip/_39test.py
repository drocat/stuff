#!/usr/bin/env python
# -*- coding: utf-8 -*-
import json
import os
import sys
import threading

import dofast as df
import requests

client = requests.Session()


class C:
    url = None

cssc = C()


def create_task(url: str) -> str:
    data = {
        'file_link': url,
        'enable_callback': 0,
        'callback_url': '',
        "hot_words": ["abc", "bbc"]
    }
    df.info(data)
    res = client.post('http://39.100.200.248:9960/api/transcript', json=data)
    j = json.loads(res.content)
    df.pp(j)
    return j['results'].get('task_id')


def get_result_once(tid: str) -> dict:
    resp = client.get('http://39.100.200.248:9960/api/transcript',
                      params={'task_id': tid})
    return json.loads(resp.content.decode('utf8').encode('gb2312'))


def round_robin(url: str):
    tid = create_task(url)
    res = get_result_once(tid)
    while res['msg'] != 'success':
        df.info(res)
        df.info("Transcript pending")
        res = get_result_once(tid)
        df.sleep(5)
    df.info("Transcript completed.")
    df.info(f"{res}")

    # write to local file
    # file_name = url.split('/')[-1].split('.')[0] + ".json"
    # df.jsonwrite(res, file_name)
    # os.system(f"coscmd upload {file_name} {file_name}")
    # cos_url = f"https://cos-1303988041.cos.ap-beijing.myqcloud.com/{file_name}"
    # df.info(f"JSON file uploaded to Tencent COS {cos_url}")

def sleepit(noarg):
    import random
    df.sleep(5)
    print("Done")

if __name__ == '__main__':
    url10 = 'http://mgvai.free.idcfengye.com/audio_10_minutes.wav'
    url5 = 'http://mgvai.free.idcfengye.com/audio_5_minutes.wav'
    url_half = 'http://mgvai.free.idcfengye.com/audio_half_minute.wav'
    fake1 = 'http://mgvai.free.idcfengye.com/1second.m4a'
    fake6 = 'http://mgvai.free.idcfengye.com/6seconds.wav'
    # audios = [url5] * 10
    audios = [url_half, url5, url10, fake1, fake6]
    for i in range(5):
        t = threading.Thread(target=round_robin, args=(audios[i], ))
        # t = threading.Thread(target=sleepit, args=(audios[i],))
        t.start()
        # df.info("Hllll")


