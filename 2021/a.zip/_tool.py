

import dofast as df

def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

r = df.smartopen('_tmp.txt')
r = [e.strip() for e in r]
rr = []
for l in chunks(r, 4):
    l[0]=int(l[0])
    rr.append(l)

df.pp(rr)
