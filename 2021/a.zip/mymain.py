import pytest
import sys
import dirtyfast as df
from models.api.transcript import *
from pkgs.ali.alislm import AliSLM
from configs.serving import TENCENT_SECRET_KEY, TENCENT_SECRTE_ID, ALIYUN_ASR_ACCESSKEYID, ALIYUN_ASR_ACCESSKEYSECRET, ALIYUN_ASR_APPKEY


class Cfg:
    url = 'https://cos-1303988041.cos.ap-beijing.myqcloud.com/audio_half_minite.wav'
    aliyun_handler = AliyunASRHandler(ASRSourceEnum.aliyun.name, 1,
                                      ali_put_audio, ali_get_res, parse_aliyun)
    tencent_handler = TencentASRHandler(ASRSourceEnum.tencent.name, 2,
                                        tencent_put_audio, tencent_get_res,
                                        parse_tencent)
    asr_input = ASRInput(url, ASRClientEnum.default.name, hot_words=['Gong'])


def new_asr_input():
    return ASRInput(Cfg.url, ASRClientEnum.default.name, hot_words=['Gong'])


@pytest.mark.skip(reason="Not now.")
def test_ali_asr():
    asr_input = new_asr_input()
    asr.handler(asr_input)
    df.p("Done")


def test_ali_slm():
    client = AliSLM(ALIYUN_ASR_ACCESSKEYID, ALIYUN_ASR_ACCESSKEYSECRET,
                    ALIYUN_ASR_APPKEY)

    # Test get  lm data list
    lm_data_list = client.get_lm_data_list()
    assert type(lm_data_list) is dict

    df.pp(lm_data_list)

    # Test get  lm data list
    data_id = '1f6696682ce24e848ed39dad748b232e'
    data_status = client.get_data_status(DataId=data_id)
    assert type(data_status) is dict

    df.p('Aliyun SLM complete.')


if __name__ == '__main__':
    test_ali_slm()
