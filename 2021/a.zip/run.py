from flask import Flask

from utils.core import router


app = Flask(__name__)


router.register_blueprints(app)
