#!/bin/bash 

for f in `git st | grep modifi | cut -d ' ' -f 4`; do 
    echo $f
    /home/gaoang/anaconda3/envs/dl/bin/yapf --in-place $f
done 

